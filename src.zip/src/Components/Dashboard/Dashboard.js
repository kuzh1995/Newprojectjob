import React, { useEffect } from 'react';

const Dashboard = ({
  restoData,
  customAmount,
  regularAmounts,
  saveButtonDisabled,
  setCustomAmount,
  setRegularAmounts,
  handleSave,
  setSaveButtonDisabled, // Add this prop
}) => {
  useEffect(() => {
    // Check if save button should be enabled or disabled
    setSaveButtonDisabled(customAmount <= 99 || Object.values(regularAmounts).some(amount => amount <= 19));
  }, [customAmount, regularAmounts, setSaveButtonDisabled]);

  return (
    <div>
      <h1>{restoData.name}</h1>
      <p>Location: {restoData.location}</p>
      <p>Charge Customers: {restoData.charge_customers ? 'Yes' : 'No'}</p>

      {restoData.charge_customers && (
        <div>
          <label>Custom Song Request Amount: </label>
          <input type="number" value={customAmount} onChange={(e) => setCustomAmount(e.target.value)} />
          <br />

          <label>Regular Song Request Amounts:</label>
          <br />
          {Object.entries(regularAmounts).map(([category, amount]) => (
            <div key={category}>
              <label>{category}:</label>
              <input
                type="number"
                value={amount}
                onChange={(e) => setRegularAmounts({ ...regularAmounts, [category]: e.target.value })}
              />
            </div>
          ))}
          <br />

          <button onClick={handleSave} disabled={saveButtonDisabled}>
            Save
          </button>
        </div>
      )}
    </div>
  );
};

export default Dashboard;
