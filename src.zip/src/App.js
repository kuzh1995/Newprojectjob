import React, { useState, useEffect } from 'react';
import Login from './Components/Login/Login';
import Dashboard from './Components/Dashboard/Dashboard';

const App = () => {
  const [loggedIn, setLoggedIn] = useState(false);
  const [restoData, setRestoData] = useState({});
  const [customAmount, setCustomAmount] = useState(100);
  const [regularAmounts, setRegularAmounts] = useState({
    category_7: 80,
    category_8: 60,
    category_9: 40,
    category_10: 20,
  });
  const [saveButtonDisabled, setSaveButtonDisabled] = useState(false);

  const handleLogin = async (username, password) => {
    try {
      const response = await fetch('https://stg.dhunjam.in/account/admin/login', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          username: username,
          password: password,
        }),
      });

      const data = await response.json();

      if (data.status === 200) {
        setLoggedIn(true);
        const userId = data.data.id;
        fetchData(userId);
      } else {
        // Handle login error
        console.error('Login failed');
      }
    } catch (error) {
      console.error('Error during login:', error);
    }
  };

  const fetchData = async (userId) => {
    try {
      const response = await fetch(`https://stg.dhunjam.in/account/admin/${userId}`);

      const data = await response.json();

      if (data.status === 200) {
        setRestoData(data.data);
        setCustomAmount(data.data.amount.category_6);
        setRegularAmounts({
          category_7: data.data.amount.category_7,
          category_8: data.data.amount.category_8,
          category_9: data.data.amount.category_9,
          category_10: data.data.amount.category_10,
        });
      } else {
        // Handle fetch data error
        console.error('Error fetching data');
      }
    } catch (error) {
      console.error('Error during data fetch:', error);
    }
  };

  const handleSave = async () => {
    try {
      const response = await fetch(`https://stg.dhunjam.in/account/admin/${restoData.id}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          amount: {
            category_6: customAmount,
          },
        }),
      });

      const data = await response.json();

      if (data.status === 200) {
        setSaveButtonDisabled(true);
        // Fetch updated data after saving
        fetchData(restoData.id);
      } else {
        // Handle save error
        console.error('Save failed');
      }
    } catch (error) {
      console.error('Error during save:', error);
    }
  };

  useEffect(() => {
    // Check if save button should be enabled or disabled
    setSaveButtonDisabled(customAmount <= 99 || Object.values(regularAmounts).some(amount => amount <= 19));
  }, [customAmount, regularAmounts]);

  return (
    <div>
      {loggedIn ? (
        <Dashboard
          restoData={restoData}
          customAmount={customAmount}
          regularAmounts={regularAmounts}
          saveButtonDisabled={saveButtonDisabled}
          setCustomAmount={setCustomAmount}
          setRegularAmounts={setRegularAmounts}
          handleSave={handleSave}
        />
      ) : (
        <Login onLogin={handleLogin} />
      )}
    </div>
  );
};

export default App;